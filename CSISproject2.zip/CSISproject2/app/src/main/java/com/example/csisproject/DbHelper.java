package com.example.csisproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "healthcare.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "month_data";
    public static final String COLUMN_ID = "id"; // Added a new column for a unique identifier
    public static final String COLUMN_YEAR = "year"; // New column for the year
    public static final String COLUMN_MONTH = "month"; // New column for the month
    public static final String COLUMN_DAY = "day";
    public static final String COLUMN_DATA = "data";

    private static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_YEAR + " INTEGER, " +
                    COLUMN_MONTH + " INTEGER, " +
                    COLUMN_DAY + " INTEGER, " +
                    COLUMN_DATA + " TEXT)";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades if needed
        // For now, we can just drop and recreate the table
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
    public List<Item> readDataFromDatabase(SQLiteDatabase db) {
        List<Item> itemList=new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM " + DbHelper.TABLE_NAME, null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_ID));
                int year = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_YEAR));
                int month = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_MONTH));
                int dayOfMonth = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_DAY));
                String data = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_DATA));

                // Create a model object with the retrieved data
                Item item = new Item(id,year, month, dayOfMonth, data);
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }
    public void updateItem(int id, int year, int month, int day, String data) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_YEAR, year);
        values.put(COLUMN_MONTH, month);
        values.put(COLUMN_DAY, day);
        values.put(COLUMN_DATA, data);

        db.update(TABLE_NAME, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }
}