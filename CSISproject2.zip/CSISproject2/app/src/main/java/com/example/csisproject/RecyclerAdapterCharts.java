package com.example.csisproject;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class RecyclerAdapterCharts extends RecyclerView.Adapter<RecyclerAdapterCharts.ViewHolder> {
    private List<Item> itemList;
    ArrayList<Entry> entries;

    public RecyclerAdapterCharts(List<Item> itemList) {

        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.secondpage, null, false);

        return new RecyclerAdapterCharts.ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapterCharts.ViewHolder holder, int position) {
        Item item = itemList.get(position);

        String month = item.getYear() + "-" + item.getMonth();
        ArrayList<BarEntry> entries = new ArrayList<>();
        double totalCalories = 0;
        List<Item> monthItems = new ArrayList<>();
        String monthDate = null;

        for (Item monthItem : itemList) {
            if (month.equals(monthItem.getYear() + "-" + monthItem.getMonth())) {
                entries.add(new BarEntry(monthItem.getDayOfMonth(), Float.parseFloat(monthItem.getData())));
                monthItems.add(monthItem);
                totalCalories += Double.parseDouble(monthItem.getData());
                monthDate=monthItem.getYear() + "-" + monthItem.getMonth();
            }
        }

        BarChart chart = holder.barChart; // Change to BarChart
        chart.setDescription(null);

        List<Integer> allDays = new ArrayList<>();
        for (int i = 1; i <= 31; i++) {
            allDays.add(i);
        }

        for (Integer day : allDays) {
            boolean hasDataForDay = false;
            for (Item monthItem : monthItems) {
                if (day == monthItem.getDayOfMonth()) {
                    hasDataForDay = true;
                    break;
                }
            }
            if (!hasDataForDay) {
                entries.add(new BarEntry(day, 0)); // Change to BarEntry
            }
        }

        BarDataSet dataSet = new BarDataSet(entries, "Calories"); // Change to BarDataSet
        dataSet.setColor(Color.BLUE);
        BarData barData = new BarData(dataSet); // Change to BarData

        double averageCalories = calculateAverageCalories(monthItems);

        holder.CalculatedAmount.setText(String.format("Total for "+monthDate+": %.2f", totalCalories));
        holder.AverageStatement.setText(String.format("Average: %.2f", averageCalories));

        // Configure x-axis labels and y-axis labels
        XAxis xAxis = chart.getXAxis();
        YAxis yAxis = chart.getAxisLeft();

        yAxis.setAxisMinimum(0);
        yAxis.setAxisMaximum(5000f);
        yAxis.setSpaceMin(10f);

        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                // Convert value to day representation
                int day = (int) value;
                return String.valueOf(day);
            }
        });

        chart.setData(barData); // Change to set barData
        chart.invalidate();
    }









    private double calculateAverageCalories(List<Item> items) {
        int sum = 0;
        int count = items.size();

        for (Item item : items) {
            sum += Integer.parseInt(item.getData());
        }

        if (count > 0) {
            return (double) sum / count;
        } else {
            return 0.0;
        }
    }

    //create chart
    private LineChart createChart(RecyclerAdapterCharts.ViewHolder holder) {
        LineChart chart = new LineChart(holder.itemView.getContext());

        chart.getDescription().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setDragEnabled(false);
        chart.setScaleEnabled(false);

        return chart;
    }
    //average calories for the month

    @Override
    public int getItemCount() {
        HashSet<String> uniqueMonths = new HashSet<>();
        for (Item item : itemList) {
            String month = item.getYear() + "-" + item.getMonth();
            uniqueMonths.add(month);
        }
        return uniqueMonths.size();
    }
    //view-holder self explanatory
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public BarChart barChart;

        TextView AverageStatement;
        TextView CalculatedAmount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            barChart = itemView.findViewById(R.id.chart);
            CalculatedAmount=itemView.findViewById(R.id.Calculated_amount);
            AverageStatement=itemView.findViewById(R.id.textView4);

        }
    }
}
