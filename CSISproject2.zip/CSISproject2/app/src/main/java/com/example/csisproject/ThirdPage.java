package com.example.csisproject;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ThirdPage extends AppCompatActivity {

    RecyclerView.LayoutManager layoutManager;
    private RecyclerView recyclerView;
    RecyclerAdapter recyclerAdapter;
    private SQLiteDatabase db ;

    private List<Item> dataList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thirdpage);
        recyclerView =findViewById(R.id.recyclerView);
        layoutManager=new LinearLayoutManager(this);
        DbHelper dbHelper = new DbHelper(this);
        db = dbHelper.getReadableDatabase();
        List<Item> itemList=dbHelper.readDataFromDatabase(db);
        recyclerView.setLayoutManager(layoutManager);
        recyclerAdapter=new RecyclerAdapter(db,itemList);
        recyclerView.setAdapter(recyclerAdapter);

    }

    public void clearDatabase(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete All Data");
        builder.setMessage("Are you sure you want to delete all data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DbHelper dbHelper = new DbHelper(ThirdPage.this);
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.execSQL("DELETE FROM " + DbHelper.TABLE_NAME);
                db.close();
                dataList.clear();
                recyclerAdapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("No", null);
        builder.show();
    }
}
