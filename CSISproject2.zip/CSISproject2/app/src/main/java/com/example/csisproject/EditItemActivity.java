package com.example.csisproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editlayout);
        Intent intent = getIntent();
        int id=intent.getIntExtra("item_id",0);
        int itemMonth = intent.getIntExtra("item_month",0);
        int itemYear = intent.getIntExtra("item_year", 0);
        int itemDay = intent.getIntExtra("item_day", 0);
        String itemCalories = intent.getStringExtra("item_calories");
        EditText monthEditText = findViewById(R.id.monthEditText);
        EditText yearEditText = findViewById(R.id.yearEditText);
        EditText dayEditText=findViewById(R.id.dayEditText);
        EditText calorieEditText=findViewById(R.id.calorieEditText);
        Button update=findViewById(R.id.UpdateButton);
        monthEditText.setText(String.valueOf(itemMonth));
        yearEditText.setText(String.valueOf(itemYear));
        dayEditText.setText(String.valueOf(itemDay));
        calorieEditText.setText(String.valueOf(itemCalories));
        DbHelper dbHelper = new DbHelper(this);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int editedMonth = 0;
                int editedYear = 0;
                int editedDay = 0;
                String editedCalories = null;
                editedMonth= Integer.parseInt(monthEditText.getText().toString());
                editedYear=Integer.parseInt(yearEditText.getText().toString());
                editedDay=Integer.parseInt(dayEditText.getText().toString());
                editedCalories= calorieEditText.getText().toString();
                dbHelper.updateItem(id, editedYear,editedMonth, editedDay, editedCalories);

                finish();

            }
        });

    }

}
