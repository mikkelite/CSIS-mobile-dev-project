package com.example.csisproject;

import static androidx.core.app.ActivityCompat.recreate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.CollationElementIterator;
import java.time.Month;
import java.util.ArrayList;

import java.util.List;


public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {


    private final SQLiteDatabase db ;
    private List<Item> dataList = new ArrayList<>();
    public RecyclerAdapter(SQLiteDatabase database,List<Item> dataList) {
        this.db = database;
        this.dataList=dataList;
        // Read data from the database and populate the dataList
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recylerviewitem, parent, false);
        return new ViewHolder(v);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder,int position) {
        Item item = dataList.get(holder.getAdapterPosition());
        holder.Month.setText("Month: "+String.valueOf(item.getMonth()));
        holder.Calories.setText("Calories: "+item.getData());
        holder.Year.setText("Year: "+String.valueOf(item.getYear()));
        holder.Day.setText("Day: "+String.valueOf(item.getDayOfMonth()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle item click
                Item clickedItem = dataList.get(holder.getAdapterPosition());

                Intent intent = new Intent(v.getContext(), EditItemActivity.class);
                intent.putExtra("item_id",clickedItem.getId());
                intent.putExtra("item_month", item.getMonth());
                intent.putExtra("item_year", item.getYear());
                intent.putExtra("item_day", item.getDayOfMonth());
                intent.putExtra("item_calories", item.getData());

                v.getContext().startActivity(intent);

            }
        });
    }
    @Override
    public int getItemCount() {

        return dataList.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView Year;
        TextView Day;
        TextView Calories;
        TextView Month;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Year=itemView.findViewById(R.id.YearText);
            Month =itemView.findViewById(R.id.MonthText);
            Day =itemView.findViewById(R.id.DayText);
            Calories =itemView.findViewById(R.id.CaloriesText);

        }
    }
}
