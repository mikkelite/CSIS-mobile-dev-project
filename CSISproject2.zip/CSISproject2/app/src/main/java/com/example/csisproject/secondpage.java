package com.example.csisproject;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.LineChart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class secondpage extends AppCompatActivity {
    TextView textView;
    TextView textView2;
    LineChart lineChart;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    RecyclerAdapterCharts recyclerAdapter;
    SQLiteDatabase db;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondpagerecycler);
        recyclerView=findViewById(R.id.recyclerView2);
        layoutManager=new LinearLayoutManager(this);
        DbHelper dbHelper = new DbHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<Item> itemList = dbHelper.readDataFromDatabase(db);
        recyclerView.setLayoutManager(layoutManager);
        recyclerAdapter = new RecyclerAdapterCharts(itemList);
        recyclerView.setAdapter(recyclerAdapter);
    }

}
