package com.example.csisproject;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


import java.time.LocalDate;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private TextView textView ;
    private Button Button;
    private Button Button2;
    private ImageView ImageView;
    private EditText editText;
    private DbHelper dbHelper;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.firstpage);
        Button2=findViewById(R.id.button3);
        Button=findViewById(R.id.button);
        textView=findViewById(R.id.textView);
        ImageView=findViewById(R.id.imageView);
        editText=findViewById(R.id.editTextText);
        textView.setText(String.format("today's date is %s", LocalDate.now().toString()));
        dbHelper = new DbHelper(this);

    }
    public void AddtoMonth(View view) {
        int year = LocalDate.now().getYear();
        int month = LocalDate.now().getMonthValue();
        int dayOfMonth = LocalDate.now().getDayOfMonth();
        String data = editText.getText().toString();

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DbHelper.COLUMN_YEAR, year);
        values.put(DbHelper.COLUMN_MONTH, month);
        values.put(DbHelper.COLUMN_DAY, dayOfMonth);
        values.put(DbHelper.COLUMN_DATA, data);
        Cursor cursor = db.query(
                DbHelper.TABLE_NAME,
                null,
                DbHelper.COLUMN_YEAR + "=? AND " +
                        DbHelper.COLUMN_MONTH + "=? AND " +
                        DbHelper.COLUMN_DAY + "=?",
                new String[] {String.valueOf(year), String.valueOf(month), String.valueOf(dayOfMonth)},
                null,
                null,
                null
        );

        if (cursor.moveToFirst()) {
            // Data already exists, handle accordingly (e.g., show a message)
            textView.setText("Data already exists for the current date.");
        } else {
              db.insert(DbHelper.TABLE_NAME, null, values);
              textView.setText("Data added successfully.");
        }
        db.close();

    }

    public void GoToPage(View view) {
        Intent intent=new Intent(MainActivity.this,secondpage.class);
        startActivity(intent);
    }
    public void EditData(View view) {
        Intent intent=new Intent(MainActivity.this,ThirdPage.class);
        startActivity(intent);
    }
}